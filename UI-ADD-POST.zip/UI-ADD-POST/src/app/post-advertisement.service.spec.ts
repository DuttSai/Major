import { TestBed, inject } from '@angular/core/testing';

import { PostAdvertisementService } from './post-advertisement.service';

describe('PostAdvertisementService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PostAdvertisementService]
    });
  });

  it('should be created', inject([PostAdvertisementService], (service: PostAdvertisementService) => {
    expect(service).toBeTruthy();
  }));
});
