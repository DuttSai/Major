import { Injectable } from '@angular/core';
import { PostAd } from './post';
import { Observable} from 'rxjs/Observable';
import "rxjs/add/observable/of"

@Injectable()
export class PostAdvertisementService {
  

  posts : PostAd[] = [];
  constructor() { }
  
  addPost(postObj : PostAd)
  {
   this.posts.push(postObj);
  }
 
  getPost():Observable<PostAd[]>{
    return Observable.of(this.posts);
  }


}
