import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { Routes, Router, RouterModule} from '@angular/router';

import { AppComponent } from './app.component';
import { PostAdComponent } from './post-ad/post-ad.component';
import { PostAdvertisementService } from './post-advertisement.service';
import { ShowPostComponent } from './show-post/show-post.component';

const appRoutes: Routes=[
  {path:'', component:PostAdComponent},
  {path:'showpost', component:ShowPostComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    PostAdComponent,
    ShowPostComponent
  ],
  imports: [
    BrowserModule, FormsModule, HttpModule, RouterModule.forRoot(appRoutes)
  ],
  providers: [PostAdvertisementService],
  bootstrap: [AppComponent]
})
export class AppModule { }
