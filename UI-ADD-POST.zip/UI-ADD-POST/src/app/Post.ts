export class PostAd{
    id : number;
    postName : string;
    postPrice : number;
    postDes : string;
    image : string;
}