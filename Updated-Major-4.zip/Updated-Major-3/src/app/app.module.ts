import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import {Routes,RouterModule} from '@angular/router'
import { CommonService } from './common.service';
import {FormsModule} from '@angular/forms'
import {HttpModule} from "@angular/http";
import { HomeComponent } from './home/home.component';
import { NavBarComponent } from './nav-bar/nav-bar.component';
import { LoggedInComponent } from './logged-in/logged-in.component';
import { PostComponent } from './post/post.component';
import { ShowPostComponent } from './show-post/show-post.component';
import { DescriptionComponent } from './description/description.component';
const routes:Routes=[
  {path:'',component:HomeComponent},
  {path:'login',component:LoginComponent},
  {path:'register',component:RegisterComponent},
  {path:'signin',component:LoggedInComponent},
  {path:'post',component:PostComponent},
  {path:'showposts',component:ShowPostComponent},
  {path:'description',component:DescriptionComponent}
]
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    HomeComponent,
    NavBarComponent,
    LoggedInComponent,
    PostComponent,
    ShowPostComponent,
    DescriptionComponent,
  ],
  imports: [
    BrowserModule,HttpModule,FormsModule,RouterModule.forRoot(routes)
  ],
  providers: [CommonService],
  bootstrap: [AppComponent]
})
export class AppModule { }
