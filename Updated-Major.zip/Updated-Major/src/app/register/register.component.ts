import { Component, OnInit } from '@angular/core';
import { CommonService } from '../common.service';
import { Router } from '@angular/router';
import { Register } from '../register';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private newService:CommonService,private router:Router) { }
  ngOnInit() {
 }
  onSave(users){
    //  [a-z.\s-]+[@]capgemini[.][a-z]+
    this.newService.saveUser(users).subscribe(data=>{alert(data.data)})
    this.router.navigate([''])
  }

}
