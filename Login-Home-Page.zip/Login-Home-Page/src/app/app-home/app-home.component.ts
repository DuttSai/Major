import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-home',
  templateUrl: './app-home.component.html',
  styleUrls: ['./app-home.component.css']
})
export class AppHomeComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }
  public mobile()
  {
  this.router.navigate(['./mobiles']);
  }
  public electronics()
  {
  this.router.navigate(['./electronics']);
  }
  public books()
  {
  this.router.navigate(['./books']);
  }
  public furniture()
  {
  this.router.navigate(['./furniture']);
  }
}
