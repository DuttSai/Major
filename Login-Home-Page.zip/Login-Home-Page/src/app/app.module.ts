import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http'
import { Route, RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { AppHeaderComponent } from './app-header/app-header.component';
import { AppLoginComponent } from './app-login/app-login.component';
import { AppHomeComponent } from './app-home/app-home.component';
import { AppRegisterComponent } from './app-register/app-register.component';
import { AppCategoryComponent } from './app-category/app-category.component';
import { MobilesComponent } from './mobiles/mobiles.component';
import { ElectronicsComponent } from './electronics/electronics.component';
import { BooksComponent } from './books/books.component';
import { FurnitureComponent } from './furniture/furniture.component';
import { DescriptionComponent } from './description/description.component';

const ROUTES: Route[] = [
   { path: '', component: AppLoginComponent},
   { path: 'home', component: AppHomeComponent},
   { path: 'register', component: AppRegisterComponent},
   {path:'mobiles', component:MobilesComponent},
   {path:'electronics',component:ElectronicsComponent},
   {path:'books',component:BooksComponent},
   {path:'furniture',component:FurnitureComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    AppHeaderComponent,
    AppLoginComponent,
    AppHomeComponent,
    AppRegisterComponent,
    AppCategoryComponent,
    MobilesComponent,
    ElectronicsComponent,
    BooksComponent,
    FurnitureComponent,
    DescriptionComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    RouterModule.forRoot(ROUTES)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
