import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { login } from '../../../login';

@Component({
  selector: 'app-app-login',
  templateUrl: './app-login.component.html',
  styleUrls: ['./app-login.component.css']
})
export class AppLoginComponent implements OnInit {
  loginArr: login[]=[]
  loginObj: login = new login()
  temp:number=0
  temp2:number=0
  constructor(private router: Router) { }

  ngOnInit() {
  }
  
  public onLoginClick(){
    this.router.navigate(['./home']);
}
public onRegisterClick(){
  this.router.navigate(['./register']);
}
}
