import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http'
import { Route, RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { AppHeaderComponent } from './app-header/app-header.component';
import { AppLoginComponent } from './app-login/app-login.component';
import { AppHomeComponent } from './app-home/app-home.component';
import { AppRegisterComponent } from './app-register/app-register.component';

const ROUTES: Route[] = [
   { path: '', component: AppLoginComponent},
   { path: 'home', component: AppHomeComponent},
   { path: 'register', component: AppRegisterComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    AppHeaderComponent,
    AppLoginComponent,
    AppHomeComponent,
    AppRegisterComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    RouterModule.forRoot(ROUTES)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
