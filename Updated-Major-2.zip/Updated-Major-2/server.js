const express = require("express")
var multer  = require('multer')
var upload=multer({dest:'images/'})
//images
const bodyParser = require("body-parser")
const path= require ("path");
const mongo= require("mongoose");
const cors=require("cors")


var db= mongo.connect("mongodb://127.0.0.1:27017/Olxdb",function(err,response){
    if(err){
        console.log(err)
    }
    else{
        console.log("connected to"+db,"+",response);
    }
})


var app=new express();
// app.use(cors({origin:/SaveUser/,methods:["GET","POST"]}))
app.use(cors())
// app.use(bodyParser())
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended:true}))

// app.use(function (req,res,next){
//     res.setHeader("Access-Control-Allow-Origin","http://localhost:4200")
//     res.setHeader("Access-Control-Allow-Methods","GET,POST,OPTIONS,PUT,DELETE,PATCH")
//     res.setHeader("Access-Control-Allow-Headers","X-Requested-With,content-type")
//     res.setHeader("Access-Control-Allow-Credentials",true)

//     next();
// });

var Schema=mongo.Schema;


var UsersData=new Schema({
    name:{type:String},
    email:{type:String},
    username:{type:String},
    password:{type:String},
    repassword:{type:String},
})
 
var PostData=mongo.Schema({
    postName:{type:String},
    postPrice:{type:Number},
    postDes:{type:String},
    image:{data:Buffer, contentType:String}

})

// var model= mongo.model("users",UsersSchema,"users");  data:Buffer, contentType:String
var model=mongo.model("usersdata",UsersData,"usersdata")
var model2=mongo.model("postdata",PostData,"postdata")

// saving users registered data

app.post("/api/SaveUser",function(req,res){
    var mod=new model(req.body);
    mod.save(function(err,data){
        if(err){
            res.send({data:""+err})
        }
        else{
            res.send({data:"User Data Registerd Successfully"})
        }
    })
}) 


// saving Posted data


app.post("/api/postData",upload.single('image'),(req,res)=>{
    var pod=new model2(req.body,req.file)
    pod.save((err,data)=>{
        if(err){
            res.send({data:""+err})
        }
        else{
            res.send({data:"Post saved successfully"})
        }
    })
})



//Retrieving users registerd data from database 

app.get("/api/getUser",function(req,res){
    model.find({},function(err,data){
        if(err){
            res.send(err)
        }
        else
        {
            console.log("User data retrieved successfully")
            res.send(data)

        }
    })
});

//Retrieving users registerd data from database 

app.get("/api/getPosts",function(req,res){
    model2.find({},(err,data)=>{
        if(err){
            res.send(err)
        }
        else{
            console.log("Posts retrieved successfully")
            res.send(data)
        }
    })
})

app.listen(8000,function(){
    console.log("yo  listen   8080")
})
