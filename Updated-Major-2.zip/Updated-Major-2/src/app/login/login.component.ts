import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from '../common.service';
import { Users } from '../users';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  flag:boolean = false;
  constructor(private router: Router, private newService: CommonService) { }
  registeredData
  errorMsg: string
  users: Users = new Users()
  title:string="BUY N SELL @CAPGEMINI"
  ngOnInit() {
    this.newService.GetUser().subscribe((data) => this.registeredData = data)
  }
  onSigninClick() {
    if (!this.users.username || !this.users.password) {
      return
    }
    else {
      this.errorMsg = "Username or Password is incorrect"
      for (let k of this.registeredData) {
        if (k.username == this.users.username) {
          if (k.password == this.users.password) {
            this.errorMsg = "Logged in Scuccesfully";
            this.flag=true;
            console.log(this.flag);
            this.newService.auth4(this.flag);
            this.router.navigate(['signin'])
          }
        }
      }
      alert(this.errorMsg)
    }
    this.newService.setUserName(this.users)
  }
  onSignupClick() {
    this.router.navigate(['register'])
  }

}
