export class Post {
    postName : string;
    postPrice : number;
    postDes : string;
    image:String
}
