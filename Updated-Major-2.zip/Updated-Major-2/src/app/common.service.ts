import { Injectable } from '@angular/core';
import {Http,Response,Headers,RequestOptions} from '@angular/http'

import {Observable} from 'rxjs/Observable'
import 'rxjs/add/operator/map'
import 'rxjs/add/operator/do'
import "rxjs/add/observable/of"

import { Users } from './users';
import { Post } from './post';
@Injectable()
export class CommonService {
flag:boolean=true;
  constructor(private http:Http) { }
  users: Users = new Users()
  // postData:Post=new Post()
  usn:string

setUserName(users:Users){
    localStorage.setItem(this.usn,users.username)
}

// addPost(postObj : Post)
//   {
//    this.posts.push(postObj);
//   }
 
//   getPost():Observable<Post[]>{
//     return Observable.of(this.posts);
//   }
auth4(fl:boolean){
  console.log("hello")
  
  this.flag=fl;
  console.log(this.flag);
}
auth():Observable<boolean>{
  console.log("hi");
  console.log(this.flag);
return Observable.of(this.flag);
}
saveUser(users){
return this.http.post('http://localhost:8000/api/SaveUser/',users).map((response:Response)=>response.json())
}
GetUser(){
  return this.http.get('http://localhost:8000/api/getUser/').map((response:Response)=>response.json())
  }
  deleteUser(id){
    return this.http.post('http://localhost:8000/api/deleteUser/',{'id':id}).map((response:Response)=>response.json())
    }
    addPost(posts){
      return this.http.post('http://localhost:8000/api/postData/',posts).map((response:Response)=>response.json())
    }
    GetPosts(){
      return this.http.get('http://localhost:8000/api/getposts/').map((response:Response)=>response.json())
      }
}
