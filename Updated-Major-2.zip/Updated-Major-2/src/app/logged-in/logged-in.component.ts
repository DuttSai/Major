import { Component, OnInit, Input } from '@angular/core';
import { CommonService } from '../common.service';
import { Router } from '@angular/router';
 

@Component({
  selector: 'app-logged-in',
  templateUrl: './logged-in.component.html',
  styleUrls: ['./logged-in.component.css'],
})
export class LoggedInComponent implements OnInit {
  // currentUser: any;
  flag:boolean = true;
  constructor( private newservice:CommonService,private router:Router) { }
  usn2:string
  ngOnInit() {
     this.usn2=localStorage.getItem(this.newservice.usn)
     this.newservice.auth().subscribe((flag1 => {
      this.flag = flag1;
      console.log(this.flag);
    }))
  }
  // isUserLoggedIn=true;
title:String="BUY N SELL @CAPGEMINI"
addPostClick(){
this.router.navigate(['post'])
}

 
logoutClick(){
  
  // this.isUserLoggedIn=false;
  // if(this.currentUser==null){
  //   return false;
  // }
  // return true;
  this.flag=false;
this.newservice.auth4(this.flag);
this.router.navigate([''])
}
}
