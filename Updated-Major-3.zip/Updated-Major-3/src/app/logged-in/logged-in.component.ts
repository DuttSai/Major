import { Component, OnInit, Input } from '@angular/core';
import { CommonService } from '../common.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-logged-in',
  templateUrl: './logged-in.component.html',
  styleUrls: ['./logged-in.component.css'],
})
export class LoggedInComponent implements OnInit {

  constructor( private newservice:CommonService,private router:Router) { }
// temp
  usn2:string
  ngOnInit() {
     this.usn2=localStorage.getItem(this.newservice.usn)
  // alert("component"+this.usn2)
  // this.newservice.increase()
  // alert(this.temp)
  // alert("service"+this.newservice.temp)
    }
  // isUserLoggedIn=true;
title:String="BUY N SELL @CAPGEMINI"
addPostClick(){
this.router.navigate(['post'])
}
logoutClick(){
  // this.isUserLoggedIn=false;
this.router.navigate([''])
localStorage.removeItem(this.newservice.usn)
// alert("service"+this.newservice.usn)
this.usn2=localStorage.getItem(this.newservice.usn)
// alert("component"+this.usn2)
}
loginClick(){
this.router.navigate(['login'])

}
}
