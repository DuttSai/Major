import { Component, OnInit } from '@angular/core';
import { CommonService } from '../common.service';
import { Post } from '../post';
import { Router } from '@angular/router';

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent implements OnInit {
user
registeredData
email
  constructor(private newservice:CommonService,private router:Router) { }
  post:Post=new Post()
  ngOnInit() {
    this.newservice.GetUser().subscribe((data) => this.registeredData = data)
this.user=localStorage.getItem(this.newservice.usn)
alert("from post component"+this.user)
// for(let e of this.registeredData){
//   if(this.user=e.username){
//     this.email=e.email
//   }
// }
// alert("eamil: "+this.email)
this.email=this.newservice.getEmail()
alert("from post component"+this.email)
}
  addPost(posts){
    this.newservice.addPost(posts).subscribe(data=>{alert(data.data)})
    this.router.navigate(["showposts"])
    alert(this.post.category)
  }
  loginClick(){
    this.router.navigate(['login'])
    }

}
