import { Injectable } from '@angular/core';
import {Http,Response,Headers,RequestOptions} from '@angular/http'

import {Observable} from 'rxjs/Observable'
import 'rxjs/add/operator/map'
import 'rxjs/add/operator/do'
import "rxjs/add/observable/of"

import { Users } from './users';
import { Post } from './post';
@Injectable()
export class CommonService {

  constructor(private http:Http) { }
  users: Users = new Users()
  // postData:Post=new Post()
  usn:string
  email:string
  // temp=1
setUserName(users:Users){
    localStorage.setItem(this.usn,users.username)
}
setEmail(e:string)
{
this.email=e
}
getEmail(){
  return this.email
}
// inc():Observable<any>{
//   this.temp=2
//   return Observable.of(this.temp)
// }
// addPost(postObj : Post)
//   {
//    this.posts.push(postObj);
//   }
 
//   getPost():Observable<Post[]>{
//     return Observable.of(this.posts);
//   }

saveUser(users){
return this.http.post('http://localhost:8080/api/SaveUser/',users).map((response:Response)=>response.json())
}
GetUser(){
  return this.http.get('http://localhost:8080/api/getUser/').map((response:Response)=>response.json())
  }
  deleteUser(id){
    return this.http.post('http://localhost:8080/api/deleteUser/',{'id':id}).map((response:Response)=>response.json())
    }
    addPost(posts){
      return this.http.post('http://localhost:8080/api/postData/',posts).map((response:Response)=>response.json())
    }
    GetPosts(){
      return this.http.get('http://localhost:8080/api/getposts/').map((response:Response)=>response.json())
      }
}
