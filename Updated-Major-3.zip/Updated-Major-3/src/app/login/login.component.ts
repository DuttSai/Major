import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from '../common.service';
import { Users } from '../users';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router: Router, private newService: CommonService) { }
  registeredData
  errorMsg: string
  users: Users = new Users()
  title:string="BUY N SELL @CAPGEMINI"
  email
  show
  // temp
  ngOnInit() {
    this.newService.GetUser().subscribe((data) => this.registeredData = data)
    this.show=localStorage.getItem(this.newService.usn)
    // this.temp=this.newService.temp
    // alert(this.temp)
  }
  onSigninClick() {
    if (!this.users.username || !this.users.password) {
      return
    }
    else {
      this.errorMsg = "Username or Password is incorrect"
      for (let k of this.registeredData) {
        if (k.username == this.users.username) {
          if (k.password == this.users.password) {
            this.errorMsg = "Logged in Scuccesfully"
            // this.newService.inc()
            this.email=k.email
            this.router.navigate(['signin'])
          }
        }
      }
      alert(this.errorMsg)
    }
    this.newService.setUserName(this.users)
    this.newService.setEmail(this.email)
  }
  onSignupClick() {
    this.router.navigate(['register'])
  }

}
